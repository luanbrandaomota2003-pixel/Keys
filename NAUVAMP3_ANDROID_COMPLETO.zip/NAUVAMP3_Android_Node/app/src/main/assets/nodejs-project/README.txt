YOUTUBE MP3 - TERMUX (SEM PIP)

INSTALACAO SIMPLES:

1. No Termux:
   pkg update && pkg upgrade
   pkg install nodejs yt-dlp ffmpeg

2. Entre na pasta do projeto:
   cd /sdcard/Download/youtube

3. Instale as dependencias:
   npm install

4. Inicie:
   node server.js

5. Abra:
   http://localhost:3000

O projeto nao usa Python, pip ou caminho fixo no server.js.
O Node encontra yt-dlp e ffmpeg pelo PATH do Termux.
