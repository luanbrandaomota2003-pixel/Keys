const express = require('express');
const path = require('path');
const fs = require('fs');
const http = require('http');
const { execFile } = require('child_process');

const app = express();
const PORT = process.env.PORT || 3000;
const TERMUX_PREFIX = process.env.PREFIX || '/data/data/com.termux/files/usr';
const ANDROID_BIN = path.join(__dirname, 'bin');
const DOWNLOADS = path.join(__dirname, 'downloads');

if (!fs.existsSync(DOWNLOADS)) fs.mkdirSync(DOWNLOADS, { recursive: true });
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

function nativeRequest(route, payload = {}) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify(payload);
    const req = http.request({
      hostname: '127.0.0.1',
      port: 8765,
      path: route,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body)
      },
      timeout: 120000
    }, (resp) => {
      let data = '';
      resp.setEncoding('utf8');
      resp.on('data', chunk => data += chunk);
      resp.on('end', () => {
        try { resolve(JSON.parse(data || '{}')); }
        catch (e) { reject(new Error('Resposta inválida do runtime Android')); }
      });
    });
    req.on('timeout', () => req.destroy(new Error('Tempo limite do runtime Android')));
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

function run(cmd, args, options = {}) {
  return new Promise((resolve, reject) => {
    execFile(cmd, args, { maxBuffer: 50 * 1024 * 1024, ...options }, (error, stdout, stderr) => {
      if (error) return reject(Object.assign(error, { stdout, stderr }));
      resolve({ stdout, stderr });
    });
  });
}

async function findExecutable(envName, command) {
  const candidates = [
    process.env[envName],
    path.join(ANDROID_BIN, command),
    path.join(TERMUX_PREFIX, 'bin', command),
    `/data/data/com.termux/files/usr/bin/${command}`,
    command
  ].filter(Boolean);

  for (const candidate of candidates) {
    if (path.isAbsolute(candidate)) {
      if (fs.existsSync(candidate)) return candidate;
    } else {
      try {
        await run(candidate, ['-version']);
        return candidate;
      } catch (_) {}
    }
  }
  return null;
}

async function requireTool(res, envName, command, name, install) {
  const executable = await findExecutable(envName, command);
  if (!executable) {
    res.status(500).json({ error: `${name} não está disponível no runtime Android. Adicione o binário em nodejs-project/bin/${command}.` });
    return null;
  }
  return executable;
}

async function findNode() {
  const node = await findExecutable('NODE_PATH', 'node');
  if (!node) return null;
  try {
    const { stdout } = await run(node, ['-p', 'process.versions.node']);
    const major = Number(String(stdout).trim().split('.')[0]);
    if (Number.isFinite(major) && major >= 22) return node;
  } catch (_) {}
  return null;
}

async function ytDlpArgs(extraArgs, ytDlp) {
  const node = await findNode();
  const args = [];

  if (node) {
    args.push('--js-runtimes', `node:${node}`, '--remote-components', 'ejs:github');
  }

  args.push(...extraArgs);
  return args;
}

// Extrai o ID do vídeo a partir de URLs do YouTube
function extractVideoId(url) {
  const match = url.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([\w-]{11})/);
  return match ? match[1] : null;
}



// =========================
// API pública do NAUVAMP3
// =========================
const API_VERSION = '4.0.0';
const startedAt = Date.now();
const CATALOG_FILE = path.join(__dirname, 'musicas.json');

function baseUrl(req) {
  return `${req.protocol}://${req.get('host')}`;
}

function isMp3File(name) {
  return typeof name === 'string' && name.toLowerCase().endsWith('.mp3');
}

function safeMp3Name(name) {
  const filename = path.basename(String(name || ''));
  return isMp3File(filename) ? filename : null;
}

function normalizeMusicName(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function slugMusicName(value) {
  return normalizeMusicName(value).replace(/\s+/g, '-').slice(0, 90) || 'musica';
}

function loadCatalog() {
  try {
    const parsed = JSON.parse(fs.readFileSync(CATALOG_FILE, 'utf8'));
    return Array.isArray(parsed) ? parsed : [];
  } catch (_) {
    return [];
  }
}

function saveCatalog(catalog) {
  fs.writeFileSync(CATALOG_FILE, JSON.stringify(catalog, null, 2));
}

function registerMusic(title, filename, sourceId = null) {
  const catalog = loadCatalog();
  const key = normalizeMusicName(title);
  const existing = catalog.find(x => x.filename === filename || (sourceId && x.source_id === sourceId));
  const item = {
    title: String(title || path.parse(filename).name),
    normalized: key,
    filename,
    source_id: sourceId || existing?.source_id || null,
    updated_at: new Date().toISOString()
  };
  if (existing) Object.assign(existing, item);
  else catalog.push(item);
  saveCatalog(catalog);
  return item;
}

function findMusicByName(name) {
  const wanted = normalizeMusicName(name);
  if (!wanted) return null;

  const catalog = loadCatalog().filter(item => item && item.filename);
  let found = catalog.find(item => item.normalized === wanted);
  if (!found) found = catalog.find(item => item.normalized?.includes(wanted) || wanted.includes(item.normalized || '__never__'));
  if (found) {
    const filePath = path.join(DOWNLOADS, path.basename(found.filename));
    if (fs.existsSync(filePath)) return { ...found, filePath };
  }

  const files = getLocalMp3Files();
  const byFilename = files.find(item => {
    const base = normalizeMusicName(path.parse(item.filename).name);
    return base === wanted || base.includes(wanted) || wanted.includes(base);
  });
  if (byFilename) {
    return {
      title: path.parse(byFilename.filename).name,
      normalized: normalizeMusicName(path.parse(byFilename.filename).name),
      filename: byFilename.filename,
      source_id: null,
      filePath: path.join(DOWNLOADS, byFilename.filename)
    };
  }
  return null;
}

function getLocalMp3Files() {
  try {
    return fs.readdirSync(DOWNLOADS)
      .filter(isMp3File)
      .map(filename => {
        const fullPath = path.join(DOWNLOADS, filename);
        const stat = fs.statSync(fullPath);
        return { filename, stat };
      })
      .sort((a, b) => b.stat.mtimeMs - a.stat.mtimeMs);
  } catch (_) {
    return [];
  }
}

function publicTrack(req, item) {
  const origin = baseUrl(req);
  return {
    arquivo: item.filename,
    nome: path.parse(item.filename).name,
    formato: 'mp3',
    mime: 'audio/mpeg',
    tamanho_bytes: item.stat.size,
    atualizado_em: item.stat.mtime.toISOString(),
    mp3_url: `${origin}/musicas/${encodeURIComponent(item.filename)}`,
    api_url: `${origin}/api/musicas/${encodeURIComponent(item.filename)}`
  };
}

// Permite que sites, apps, players e WebViews externos consumam a API e os áudios.
app.use((req, res, next) => {
  if (req.path.startsWith('/api/') || req.path === '/api' || req.path.startsWith('/musicas/')) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,HEAD,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Range');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Length, Content-Range, Accept-Ranges');
  }
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

app.get('/api', (req, res) => {
  const origin = baseUrl(req);
  res.json({
    success: true,
    api: 'NAUVAMP3 API',
    version: API_VERSION,
    descricao: 'API pública para acessar as músicas MP3 hospedadas no NAUVAMP3.',
    site: origin,
    endpoints: {
      tocar_por_nome: `${origin}/api/musica/NOME_DA_MUSICA`,
      tocar_por_query: `${origin}/api/musica?nome=NOME_DA_MUSICA`,
      site: `${origin}/api/site`,
      musicas: `${origin}/api/musicas`,
      aleatoria: `${origin}/api/musicas/aleatoria`
    },
    exemplo_player: `<audio controls src="${origin}/api/musica/NOME_DA_MUSICA"></audio>`,
    resposta_musica: 'audio/mpeg'
  });
});

app.get('/api/site', (req, res) => {
  const files = getLocalMp3Files();
  const totalBytes = files.reduce((sum, item) => sum + item.stat.size, 0);
  res.json({
    success: true,
    nome: 'NAUVAMP3',
    descricao: 'Biblioteca e streaming de músicas em MP3.',
    site: baseUrl(req),
    api_version: API_VERSION,
    total_musicas: files.length,
    armazenamento_mp3_bytes: totalBytes,
    uptime_seconds: Math.floor((Date.now() - startedAt) / 1000),
    atualizado_em: new Date().toISOString()
  });
});

app.get('/api/musicas', (req, res) => {
  const files = getLocalMp3Files();
  const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 500);
  const musicas = files.slice(0, limit).map(item => publicTrack(req, item));
  res.json({
    success: true,
    total: files.length,
    retornadas: musicas.length,
    musicas
  });
});

app.get('/api/musicas/aleatoria', (req, res) => {
  const files = getLocalMp3Files();
  if (!files.length) return res.status(404).json({ success: false, error: 'Nenhuma música MP3 disponível no site.' });
  const item = files[Math.floor(Math.random() * files.length)];
  res.json({ success: true, musica: publicTrack(req, item) });
});

app.get('/api/musicas/:file', (req, res) => {
  const filename = safeMp3Name(req.params.file);
  if (!filename) return res.status(400).json({ success: false, error: 'Arquivo MP3 inválido.' });
  const filePath = path.join(DOWNLOADS, filename);
  if (!fs.existsSync(filePath)) return res.status(404).json({ success: false, error: 'Música não encontrada.' });
  const stat = fs.statSync(filePath);
  res.json({ success: true, musica: publicTrack(req, { filename, stat }) });
});

function streamMp3(req, res, filePath, filename) {
  const stat = fs.statSync(filePath);
  const fileSize = stat.size;
  const range = req.headers.range;

  res.setHeader('Content-Type', 'audio/mpeg');
  res.setHeader('Content-Disposition', `inline; filename="${filename.replace(/"/g, '')}"`);
  res.setHeader('Accept-Ranges', 'bytes');
  res.setHeader('Cache-Control', 'public, max-age=3600');

  if (range) {
    const match = /^bytes=(\d*)-(\d*)$/.exec(range);
    if (!match) return res.status(416).end();
    let start = match[1] ? Number(match[1]) : 0;
    let end = match[2] ? Number(match[2]) : fileSize - 1;
    if (Number.isNaN(start) || Number.isNaN(end) || start > end || start >= fileSize) {
      res.setHeader('Content-Range', `bytes */${fileSize}`);
      return res.status(416).end();
    }
    end = Math.min(end, fileSize - 1);
    const chunkSize = end - start + 1;
    res.status(206);
    res.setHeader('Content-Range', `bytes ${start}-${end}/${fileSize}`);
    res.setHeader('Content-Length', chunkSize);
    if (req.method === 'HEAD') return res.end();
    return fs.createReadStream(filePath, { start, end }).pipe(res);
  }

  res.setHeader('Content-Length', fileSize);
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(filePath).pipe(res);
}

// Link MP3 público. Pode ser usado diretamente em <audio src>, players e aplicativos.
app.get('/musicas/:file', (req, res) => {
  const filename = safeMp3Name(req.params.file);
  if (!filename) return res.status(400).send('Arquivo MP3 inválido.');
  const filePath = path.join(DOWNLOADS, filename);
  if (!fs.existsSync(filePath)) return res.status(404).send('Música não encontrada.');
  streamMp3(req, res, filePath, filename);
});

app.head('/musicas/:file', (req, res) => {
  const filename = safeMp3Name(req.params.file);
  if (!filename) return res.status(400).end();
  const filePath = path.join(DOWNLOADS, filename);
  if (!fs.existsSync(filePath)) return res.status(404).end();
  streamMp3(req, res, filePath, filename);
});


async function resolveMusicByName(req, res, requestedName) {
  const name = String(requestedName || '').trim();
  if (!name) return res.status(400).json({ success: false, error: 'Informe o nome da música na URL.' });
  if (name.length > 160) return res.status(400).json({ success: false, error: 'Nome da música muito grande.' });

  const local = findMusicByName(name);
  if (local) return streamMp3(req, res, local.filePath, local.filename);

  try {
    const result = await nativeRequest('/download-by-name', { name });
    if (!result.success || !result.filename) {
      return res.status(500).json({ success: false, error: result.error || 'Não foi possível carregar a música.' });
    }
    registerMusic(result.title || name, result.filename, result.id || '');
    const filePath = path.join(DOWNLOADS, path.basename(result.filename));
    if (!fs.existsSync(filePath)) return res.status(500).json({ success: false, error: 'O MP3 não foi criado.' });
    return streamMp3(req, res, filePath, result.filename);
  } catch (error) {
    console.error('API música por nome:', error.message);
    return res.status(500).json({ success: false, error: 'Runtime Android indisponível.' });
  }
}

// Coloque o nome diretamente na URL e receba o próprio áudio MP3.
app.get('/api/musica/:nome', (req, res) => resolveMusicByName(req, res, req.params.nome));
app.head('/api/musica/:nome', (req, res) => resolveMusicByName(req, res, req.params.nome));
app.get('/api/musica', (req, res) => resolveMusicByName(req, res, req.query.nome));
app.head('/api/musica', (req, res) => resolveMusicByName(req, res, req.query.nome));

app.post('/search', async (req, res) => {
  const query = String(req.body?.query || '').trim();
  if (!query) return res.status(400).json({ error: 'Digite o nome da música.' });
  if (query.length > 200) return res.status(400).json({ error: 'Nome da música muito grande.' });
  try {
    const result = await nativeRequest('/search', { query, limit: 8 });
    if (!result.success) return res.status(500).json({ error: result.error || 'Não foi possível pesquisar.' });
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: 'Runtime Android indisponível.' });
  }
});

app.post('/preview', async (req, res) => {
  const url = String(req.body?.url || '').trim();
  if (!url) return res.status(400).json({ error: 'URL inválida.' });
  try {
    const result = await nativeRequest('/preview', { url });
    if (!result.success) return res.status(500).json({ error: result.error || 'Não foi possível reproduzir.' });
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: 'Runtime Android indisponível.' });
  }
});

app.post('/download', async (req, res) => {
  const url = String(req.body?.url || '').trim();
  const videoId = extractVideoId(url);
  if (!url) return res.status(400).json({ error: 'Link inválido.' });

  if (videoId) {
    const cached = loadCatalog().find(item => item.source_id === videoId && item.filename);
    if (cached) {
      const cachedPath = path.join(DOWNLOADS, path.basename(cached.filename));
      if (fs.existsSync(cachedPath)) {
        return res.json({ success: true, filename: cached.filename, download: `/musicas/${encodeURIComponent(cached.filename)}`, cached: true });
      }
    }
  }

  try {
    const result = await nativeRequest('/download', { url });
    if (!result.success || !result.filename) {
      return res.status(500).json({ error: result.error || 'Não foi possível converter a música.' });
    }
    registerMusic(result.title || 'Música', result.filename, result.id || videoId || '');
    res.json({
      success: true,
      filename: result.filename,
      download: `/musicas/${encodeURIComponent(result.filename)}`,
      cached: false
    });
  } catch (error) {
    console.error('download android bridge:', error.message);
    res.status(500).json({ error: 'Runtime Android indisponível.' });
  }
});

// Rota para abrir o player nativo do navegador
app.get('/download/:file', (req, res) => {
  const filename = path.basename(req.params.file);
  const file = path.join(DOWNLOADS, filename);

  if (!fs.existsSync(file)) return res.status(404).send('Arquivo não encontrado.');

  const stat = fs.statSync(file);
  const fileSize = stat.size;
  const range = req.headers.range;

  res.setHeader('Content-Type', 'audio/mpeg');
  res.setHeader('Content-Disposition', 'inline');

  if (range) {
    const parts = range.replace(/bytes=/, "").split("-");
    const start = parseInt(parts[0], 10);
    const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
    const chunksize = (end - start) + 1;
    const fileStream = fs.createReadStream(file, { start, end });

    res.writeHead(206, {
      'Content-Range': `bytes ${start}-${end}/${fileSize}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': chunksize,
      'Content-Type': 'audio/mpeg',
    });
    fileStream.pipe(res);
  } else {
    res.setHeader('Content-Length', fileSize);
    fs.createReadStream(file).pipe(res);
  }
});

app.listen(PORT, '0.0.0.0', () => console.log(`YouTube MP3 rodando em http://localhost:${PORT}`));