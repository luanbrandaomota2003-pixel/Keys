NAUVAMP3 API 3.0

API por nome de musica.

ROTA PRINCIPAL
GET /api/musica/NOME_DA_MUSICA
GET /api/musica?nome=NOME_DA_MUSICA

A resposta da rota principal e o proprio audio MP3 (Content-Type: audio/mpeg).

Exemplo:
https://seusite.com/api/musica/Tim%20Maia%20Azul%20da%20Cor%20do%20Mar

Em HTML:
<audio controls src="https://seusite.com/api/musica/Tim%20Maia%20Azul%20da%20Cor%20do%20Mar"></audio>

Outras rotas:
GET /api
GET /api/site
GET /api/musicas
GET /api/musicas/aleatoria
GET /musicas/ARQUIVO.mp3

A API usa cache: depois que uma musica esta armazenada, chamadas seguintes pelo nome usam o MP3 local.
CORS e Range Requests estao habilitados para uso em sites, aplicativos e players.

Hospede e disponibilize apenas conteudo que voce tenha permissao para distribuir.
