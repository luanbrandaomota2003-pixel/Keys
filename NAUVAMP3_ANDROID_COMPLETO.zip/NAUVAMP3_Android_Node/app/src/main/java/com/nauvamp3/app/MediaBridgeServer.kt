package com.nauvamp3.app

import android.content.Context
import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.chaquo.python.Python
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.net.ServerSocket
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

class MediaBridgeServer(
    private val context: Context,
    private val nodeDir: File,
    private val port: Int = 8765
) {
    @Volatile private var running = false
    private var serverSocket: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()

    fun start() {
        if (running) return
        running = true
        pool.execute {
            try {
                serverSocket = ServerSocket(port, 32, java.net.InetAddress.getByName("127.0.0.1"))
                Log.i("NAUVAMP3", "Media bridge em 127.0.0.1:$port")
                while (running) {
                    val socket = serverSocket?.accept() ?: break
                    pool.execute { handle(socket) }
                }
            } catch (t: Throwable) {
                if (running) Log.e("NAUVAMP3", "Bridge falhou", t)
            }
        }
    }

    fun stop() {
        running = false
        try { serverSocket?.close() } catch (_: Exception) {}
        pool.shutdownNow()
    }

    private fun handle(socket: Socket) {
        socket.use { s ->
            try {
                s.soTimeout = 120_000
                val input = BufferedInputStream(s.getInputStream())
                val requestLine = readLine(input) ?: return
                val parts = requestLine.split(' ')
                if (parts.size < 2) return
                val method = parts[0].uppercase()
                val path = parts[1].substringBefore('?')

                var contentLength = 0
                while (true) {
                    val line = readLine(input) ?: break
                    if (line.isEmpty()) break
                    val idx = line.indexOf(':')
                    if (idx > 0) {
                        val key = line.substring(0, idx).trim().lowercase()
                        val value = line.substring(idx + 1).trim()
                        if (key == "content-length") contentLength = value.toIntOrNull() ?: 0
                    }
                }

                val bodyBytes = if (contentLength > 0) ByteArray(contentLength) else ByteArray(0)
                var offset = 0
                while (offset < bodyBytes.size) {
                    val n = input.read(bodyBytes, offset, bodyBytes.size - offset)
                    if (n <= 0) break
                    offset += n
                }
                val body = String(bodyBytes, 0, offset, StandardCharsets.UTF_8)
                val payload = if (body.isBlank()) JSONObject() else JSONObject(body)

                val response = when {
                    method == "GET" && path == "/health" -> JSONObject()
                        .put("success", true)
                        .put("python", true)
                        .put("ffmpeg", true)
                    method == "POST" && path == "/search" -> callPython("search", payload.optString("query"), payload.optInt("limit", 8))
                    method == "POST" && path == "/preview" -> callPython("preview", payload.optString("url"))
                    method == "POST" && path == "/download" -> downloadUrl(payload.optString("url"))
                    method == "POST" && path == "/download-by-name" -> downloadByName(payload.optString("name"))
                    else -> JSONObject().put("success", false).put("error", "Rota interna não encontrada")
                }
                writeJson(s, if (response.optBoolean("success", false)) 200 else 500, response)
            } catch (t: Throwable) {
                Log.e("NAUVAMP3", "Erro no bridge", t)
                try {
                    writeJson(s, 500, JSONObject().put("success", false).put("error", t.message ?: "Erro interno"))
                } catch (_: Exception) {}
            }
        }
    }

    private fun callPython(function: String, vararg args: Any): JSONObject {
        return try {
            val module = Python.getInstance().getModule("media_bridge")
            val result = module.callAttr(function, *args).toString()
            JSONObject(result)
        } catch (t: Throwable) {
            JSONObject().put("success", false).put("error", t.message ?: "Falha no Python")
        }
    }

    private fun downloadByName(name: String): JSONObject {
        if (name.isBlank()) return JSONObject().put("success", false).put("error", "Nome vazio")
        val temp = File(nodeDir, "tmp").apply { mkdirs() }
        val py = callPython("download_by_name", name, temp.absolutePath)
        return if (py.optBoolean("success")) convertDownloaded(py) else py
    }

    private fun downloadUrl(url: String): JSONObject {
        if (url.isBlank()) return JSONObject().put("success", false).put("error", "URL vazia")
        val temp = File(nodeDir, "tmp").apply { mkdirs() }
        val py = callPython("download_source", url, temp.absolutePath)
        return if (py.optBoolean("success")) convertDownloaded(py) else py
    }

    private fun convertDownloaded(data: JSONObject): JSONObject {
        val source = File(data.getString("source"))
        if (!source.exists()) return JSONObject().put("success", false).put("error", "Áudio temporário não encontrado")

        val downloads = File(nodeDir, "downloads").apply { mkdirs() }
        val safeName = File(data.optString("filename", "musica.mp3")).name
        val output = File(downloads, if (safeName.endsWith(".mp3", true)) safeName else "$safeName.mp3")

        if (!output.exists() || output.length() == 0L) {
            val command = "-y -i ${q(source.absolutePath)} -vn -map_metadata 0 -codec:a libmp3lame -q:a 2 ${q(output.absolutePath)}"
            val session = FFmpegKit.execute(command)
            if (!ReturnCode.isSuccess(session.returnCode)) {
                val logs = session.allLogsAsString ?: ""
                return JSONObject()
                    .put("success", false)
                    .put("error", "FFmpeg não conseguiu gerar o MP3")
                    .put("detail", logs.takeLast(1200))
            }
        }

        try { source.delete() } catch (_: Exception) {}
        return JSONObject()
            .put("success", true)
            .put("id", data.optString("id"))
            .put("title", data.optString("title"))
            .put("filename", output.name)
            .put("bytes", output.length())
    }

    private fun q(value: String): String = "'" + value.replace("'", "'\\''") + "'"

    private fun readLine(input: BufferedInputStream): String? {
        val bytes = ArrayList<Byte>()
        var last = -1
        while (true) {
            val b = input.read()
            if (b == -1) return if (bytes.isEmpty()) null else String(bytes.toByteArray(), StandardCharsets.UTF_8)
            if (last == '\r'.code && b == '\n'.code) {
                if (bytes.isNotEmpty()) bytes.removeAt(bytes.lastIndex)
                return String(bytes.toByteArray(), StandardCharsets.UTF_8)
            }
            bytes.add(b.toByte())
            last = b
            if (bytes.size > 32_768) throw IllegalStateException("Cabeçalho HTTP grande demais")
        }
    }

    private fun writeJson(socket: Socket, status: Int, json: JSONObject) {
        val data = json.toString().toByteArray(StandardCharsets.UTF_8)
        val reason = if (status == 200) "OK" else "Internal Server Error"
        val out = BufferedOutputStream(socket.getOutputStream())
        val headers = "HTTP/1.1 $status $reason\r\n" +
                "Content-Type: application/json; charset=utf-8\r\n" +
                "Content-Length: ${data.size}\r\n" +
                "Connection: close\r\n\r\n"
        out.write(headers.toByteArray(StandardCharsets.UTF_8))
        out.write(data)
        out.flush()
    }
}
