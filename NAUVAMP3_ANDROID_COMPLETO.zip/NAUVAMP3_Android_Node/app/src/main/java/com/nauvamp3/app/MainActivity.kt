package com.nauvamp3.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    companion object {
        init {
            System.loadLibrary("node")
            System.loadLibrary("native-lib")
        }

        @Volatile
        private var nodeStarted = false
    }

    external fun startNodeWithArguments(arguments: Array<String>): Int

    private lateinit var webView: WebView
    private lateinit var loadingBox: View
    private lateinit var statusText: TextView
    private val executor = Executors.newCachedThreadPool()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val localUrl = "http://127.0.0.1:3000"
    private var mediaBridge: MediaBridgeServer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        loadingBox = findViewById(R.id.loadingBox)
        statusText = findViewById(R.id.statusText)

        configureWebView()
        installBackHandler()
        prepareAndStartNode()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(false)
        }
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false
            override fun onPageFinished(view: WebView?, url: String?) {
                loadingBox.visibility = View.GONE
                webView.visibility = View.VISIBLE
            }
        }
        webView.visibility = View.INVISIBLE
    }

    private fun installBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }

    private fun prepareAndStartNode() {
        statusText.text = "Preparando servidor local..."
        executor.execute {
            try {
                val nodeDir = File(filesDir, "nodejs-project")
                copyAssetsFolder("nodejs-project", nodeDir)

                // Pastas graváveis fora do APK.
                File(nodeDir, "downloads").mkdirs()
                File(nodeDir, "tmp").mkdirs()

                // Python/yt-dlp e FFmpeg rodam dentro do próprio APK.
                if (!Python.isStarted()) {
                    Python.start(AndroidPlatform(this@MainActivity))
                }
                if (mediaBridge == null) {
                    mediaBridge = MediaBridgeServer(this@MainActivity, nodeDir).also { it.start() }
                }

                if (!nodeStarted) {
                    nodeStarted = true
                    Thread({
                        try {
                            startNodeWithArguments(arrayOf("node", File(nodeDir, "server.js").absolutePath))
                        } catch (t: Throwable) {
                            nodeStarted = false
                            showFatal("Falha ao iniciar Node: ${t.message}")
                        }
                    }, "NAUVAMP3-Node").start()
                }

                waitForServer()
            } catch (t: Throwable) {
                showFatal("Erro ao preparar o app: ${t.message}")
            }
        }
    }

    private fun waitForServer() {
        mainHandler.post { statusText.text = "Iniciando Node.js..." }
        val maxAttempts = 120
        for (attempt in 1..maxAttempts) {
            try {
                val connection = (URL("$localUrl/api/site").openConnection() as HttpURLConnection).apply {
                    connectTimeout = 700
                    readTimeout = 700
                    requestMethod = "GET"
                    useCaches = false
                }
                if (connection.responseCode in 200..499) {
                    connection.disconnect()
                    mainHandler.post { webView.loadUrl(localUrl) }
                    return
                }
                connection.disconnect()
            } catch (_: Exception) {
            }
            Thread.sleep(500)
        }
        showFatal("O servidor local não respondeu na porta 3000.")
    }

    private fun copyAssetsFolder(assetPath: String, target: File) {
        val children = assets.list(assetPath) ?: emptyArray()
        if (children.isEmpty()) {
            target.parentFile?.mkdirs()
            assets.open(assetPath).use { input ->
                FileOutputStream(target).use { output -> input.copyTo(output) }
            }
            return
        }

        target.mkdirs()
        for (child in children) {
            copyAssetsFolder("$assetPath/$child", File(target, child))
        }
    }

    private fun showFatal(message: String) {
        mainHandler.post {
            loadingBox.visibility = View.VISIBLE
            webView.visibility = View.INVISIBLE
            statusText.text = message
        }
    }

    override fun onDestroy() {
        webView.destroy()
        mediaBridge?.stop()
        executor.shutdownNow()
        super.onDestroy()
    }
}
