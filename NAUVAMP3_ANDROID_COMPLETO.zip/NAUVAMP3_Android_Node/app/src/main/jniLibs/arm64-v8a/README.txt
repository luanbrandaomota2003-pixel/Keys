O build.gradle baixa libnode.so automaticamente antes do build.
Se o download automático falhar, coloque aqui:
app/src/main/jniLibs/arm64-v8a/libnode.so
