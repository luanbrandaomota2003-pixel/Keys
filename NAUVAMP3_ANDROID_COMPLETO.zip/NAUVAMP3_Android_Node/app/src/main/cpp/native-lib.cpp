#include <jni.h>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <string>
#include <android/log.h>

// O libnode antigo expõe node::Start(int, char**).
// Declaramos somente o entrypoint para não precisar distribuir todos os headers do Node.
namespace node {
    int Start(int argc, char **argv);
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_nauvamp3_app_MainActivity_startNodeWithArguments(
        JNIEnv *env,
        jobject,
        jobjectArray arguments) {

    const jsize argc = env->GetArrayLength(arguments);
    std::vector<std::string> strings;
    strings.reserve(argc);

    for (jsize i = 0; i < argc; ++i) {
        auto js = (jstring) env->GetObjectArrayElement(arguments, i);
        const char *utf = env->GetStringUTFChars(js, nullptr);
        strings.emplace_back(utf ? utf : "");
        if (utf) env->ReleaseStringUTFChars(js, utf);
        env->DeleteLocalRef(js);
    }

    std::vector<char *> argv;
    argv.reserve(argc);
    for (auto &s : strings) argv.push_back(s.data());

    __android_log_print(ANDROID_LOG_INFO, "NAUVAMP3", "Iniciando Node (%d args)", (int) argc);
    return node::Start((int) argc, argv.data());
}
