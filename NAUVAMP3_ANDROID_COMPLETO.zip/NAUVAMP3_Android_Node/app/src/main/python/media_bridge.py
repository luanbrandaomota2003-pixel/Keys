import json
import os
import re
from pathlib import Path
from yt_dlp import YoutubeDL


def _slug(text):
    text = re.sub(r"[^\w\- ]+", "", str(text or ""), flags=re.UNICODE).strip()
    text = re.sub(r"\s+", "-", text)
    return (text[:90] or "musica").lower()


def _base_opts():
    return {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "socket_timeout": 20,
        "retries": 3,
        "fragment_retries": 3,
    }


def search(query, limit=8):
    try:
        opts = _base_opts()
        opts.update({"extract_flat": True, "skip_download": True})
        with YoutubeDL(opts) as ydl:
            data = ydl.extract_info(f"ytsearch{int(limit)}:{query}", download=False) or {}
        out = []
        for x in (data.get("entries") or [])[: int(limit)]:
            if not x or not x.get("id"):
                continue
            vid = x.get("id")
            out.append({
                "id": vid,
                "title": x.get("title") or "Sem título",
                "uploader": x.get("uploader") or x.get("channel") or "",
                "duration": x.get("duration") or 0,
                "thumbnail": x.get("thumbnail") or f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg",
                "url": x.get("webpage_url") or f"https://www.youtube.com/watch?v={vid}",
            })
        return json.dumps({"success": True, "results": out}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"success": False, "error": str(e)}, ensure_ascii=False)


def preview(url):
    try:
        opts = _base_opts()
        opts.update({"format": "bestaudio/best", "skip_download": True})
        with YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False) or {}
        direct = info.get("url")
        if not direct:
            formats = info.get("formats") or []
            audio = [f for f in formats if f.get("url") and f.get("acodec") not in (None, "none")]
            if audio:
                direct = audio[-1].get("url")
        if not direct:
            raise RuntimeError("Áudio não encontrado")
        return json.dumps({"success": True, "url": direct}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"success": False, "error": str(e)}, ensure_ascii=False)


def download_source(url, work_dir):
    """Baixa somente a melhor faixa de áudio. A conversão MP3 é feita pelo FFmpegKit no Android."""
    try:
        work = Path(work_dir)
        work.mkdir(parents=True, exist_ok=True)
        opts = _base_opts()
        opts.update({
            "format": "bestaudio/best",
            "outtmpl": str(work / "source-%(id)s.%(ext)s"),
            "overwrites": True,
        })
        with YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True) or {}
            path = ydl.prepare_filename(info)
        if not os.path.exists(path):
            requested = info.get("requested_downloads") or []
            for item in requested:
                fp = item.get("filepath")
                if fp and os.path.exists(fp):
                    path = fp
                    break
        if not os.path.exists(path):
            raise RuntimeError("Arquivo de áudio temporário não foi criado")
        vid = str(info.get("id") or "audio")
        title = str(info.get("title") or f"musica-{vid}")
        filename = f"{_slug(title)}-{vid}.mp3"
        return json.dumps({
            "success": True,
            "id": vid,
            "title": title,
            "source": os.path.abspath(path),
            "filename": filename,
        }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"success": False, "error": str(e)}, ensure_ascii=False)


def download_by_name(name, work_dir):
    try:
        opts = _base_opts()
        opts.update({"extract_flat": True, "skip_download": True})
        with YoutubeDL(opts) as ydl:
            data = ydl.extract_info(f"ytsearch1:{name}", download=False) or {}
        entries = [x for x in (data.get("entries") or []) if x]
        if not entries:
            return json.dumps({"success": False, "error": "Música não encontrada"}, ensure_ascii=False)
        x = entries[0]
        vid = x.get("id")
        url = x.get("webpage_url") or f"https://www.youtube.com/watch?v={vid}"
        return download_source(url, work_dir)
    except Exception as e:
        return json.dumps({"success": False, "error": str(e)}, ensure_ascii=False)
